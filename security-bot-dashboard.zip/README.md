# Security Bot Dashboard

Dashboard responsive para **Security Bot — Antonio productions**.

## Qué incluye

- Login con Discord mediante OAuth2.
- Lista de servidores que el usuario puede administrar.
- Servidores sin el bot: se muestran oscurecidos.
- Servidores con Security Bot: se muestran normalmente.
- En servidores sin bot aparece la opción para añadirlo.
- Configuración de `/panel-ticket`.
- 11 opciones configurables.
- Nombre, descripción y emoji obligatorios.
- Placeholders de ejemplo en la opción 1 que desaparecen al escribir.
- Configuración guardada por `guild_id` en SQLite.
- Diseño responsive para PC y móvil.

## Instalación

```bash
npm install
cp .env.example .env
npm start
```

Para el login real debes crear una aplicación en Discord Developer Portal y configurar OAuth2.

Scopes usados:
- identify
- guilds

La URL de callback debe coincidir con `DISCORD_REDIRECT_URI`.

## Importante

Nunca subas `.env` a GitHub. El token del bot y el client secret deben permanecer en variables de entorno.

Esta primera versión guarda la configuración y deja preparada la integración. En el siguiente paso se puede conectar el bot real para que `/panel-ticket` publique el panel configurado.
