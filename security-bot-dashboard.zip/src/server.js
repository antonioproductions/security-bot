require("dotenv").config();

const express = require("express");
const session = require("express-session");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const PORT = Number(process.env.PORT || 3000);

const db = new Database("./data.sqlite");
db.exec(`
  CREATE TABLE IF NOT EXISTS ticket_panels (
    guild_id TEXT PRIMARY KEY,
    guild_name TEXT NOT NULL,
    config_json TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )
`);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "development-secret-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: false,
    maxAge: 1000 * 60 * 60 * 24
  }
}));

app.use(express.static(path.join(__dirname, "../public")));

const DISCORD_API = "https://discord.com/api/v10";

function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "No has iniciado sesión con Discord." });
  next();
}

async function discordFetch(url, options = {}) {
  const response = await fetch(url, options);
  const text = await response.text();
  let data;
  try { data = JSON.parse(text); } catch { data = text; }

  if (!response.ok) {
    const message = data?.message || `Discord API error (${response.status})`;
    throw new Error(message);
  }
  return data;
}

function botInviteUrl(guildId) {
  const clientId = process.env.DISCORD_BOT_CLIENT_ID || process.env.DISCORD_CLIENT_ID;
  if (!clientId) return "#";
  const permissions = "0";
  return `https://discord.com/oauth2/authorize?client_id=${encodeURIComponent(clientId)}&permissions=${permissions}&scope=bot%20applications.commands&guild_id=${encodeURIComponent(guildId)}`;
}

app.get("/auth/discord", (req, res) => {
  if (!process.env.DISCORD_CLIENT_ID || !process.env.DISCORD_REDIRECT_URI) {
    return res.status(500).send("Faltan DISCORD_CLIENT_ID o DISCORD_REDIRECT_URI en .env");
  }

  const params = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID,
    redirect_uri: process.env.DISCORD_REDIRECT_URI,
    response_type: "code",
    scope: "identify guilds"
  });

  res.redirect(`https://discord.com/oauth2/authorize?${params.toString()}`);
});

app.get("/auth/discord/callback", async (req, res) => {
  try {
    const { code } = req.query;
    if (!code) return res.redirect("/?error=discord");

    const tokenBody = new URLSearchParams({
      client_id: process.env.DISCORD_CLIENT_ID,
      client_secret: process.env.DISCORD_CLIENT_SECRET,
      grant_type: "authorization_code",
      code,
      redirect_uri: process.env.DISCORD_REDIRECT_URI
    });

    const token = await discordFetch(`${DISCORD_API}/oauth2/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: tokenBody
    });

    const [user, guilds] = await Promise.all([
      discordFetch(`${DISCORD_API}/users/@me`, {
        headers: { Authorization: `Bearer ${token.access_token}` }
      }),
      discordFetch(`${DISCORD_API}/users/@me/guilds`, {
        headers: { Authorization: `Bearer ${token.access_token}` }
      })
    ]);

    req.session.user = user;
    req.session.guilds = guilds;
    req.session.accessToken = token.access_token;
    res.redirect("/dashboard.html");
  } catch (error) {
    console.error(error);
    res.redirect("/?error=login");
  }
});

app.post("/auth/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/me", (req, res) => {
  if (!req.session.user) return res.json({ loggedIn: false });
  res.json({
    loggedIn: true,
    user: req.session.user
  });
});

app.get("/api/guilds", requireAuth, async (req, res) => {
  try {
    const guilds = req.session.guilds || [];
    const botToken = process.env.DISCORD_BOT_TOKEN;

    let botGuildIds = new Set();

    if (botToken) {
      const botGuilds = await discordFetch(`${DISCORD_API}/users/@me/guilds`, {
        headers: { Authorization: `Bot ${botToken}` }
      });
      botGuildIds = new Set(botGuilds.map(g => g.id));
    }

    const result = guilds
      .filter(g => {
        // MANAGE_GUILD (0x20), ADMINISTRATOR (0x8)
        const permissions = BigInt(g.permissions || "0");
        return (permissions & 0x8n) !== 0n || (permissions & 0x20n) !== 0n;
      })
      .map(g => ({
        id: g.id,
        name: g.name,
        icon: g.icon,
        botInstalled: botGuildIds.has(g.id),
        inviteUrl: botInviteUrl(g.id)
      }));

    res.json(result);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "No se pudieron cargar los servidores." });
  }
});

app.get("/api/guilds/:guildId/panel-ticket", requireAuth, (req, res) => {
  const row = db.prepare("SELECT config_json, guild_name, updated_at FROM ticket_panels WHERE guild_id = ?").get(req.params.guildId);
  if (!row) return res.json({ configured: false });
  res.json({
    configured: true,
    guildName: row.guild_name,
    updatedAt: row.updated_at,
    config: JSON.parse(row.config_json)
  });
});

app.put("/api/guilds/:guildId/panel-ticket", requireAuth, (req, res) => {
  const guildId = req.params.guildId;
  const guild = (req.session.guilds || []).find(g => g.id === guildId);

  if (!guild) return res.status(403).json({ error: "No tienes acceso a este servidor." });

  const botToken = process.env.DISCORD_BOT_TOKEN;
  if (!botToken) return res.status(500).json({ error: "Falta DISCORD_BOT_TOKEN en .env." });

  const options = Array.isArray(req.body.options) ? req.body.options : [];

  if (options.length !== 11) {
    return res.status(400).json({ error: "Debes enviar exactamente 11 opciones." });
  }

  for (let i = 0; i < options.length; i++) {
    const item = options[i];
    if (!item || !String(item.name || "").trim() || !String(item.description || "").trim() || !String(item.emoji || "").trim()) {
      return res.status(400).json({ error: `La opción ${i + 1}: nombre, descripción y emoji son obligatorios.` });
    }
  }

  const clean = options.map(item => ({
    name: String(item.name).trim().slice(0, 80),
    description: String(item.description).trim().slice(0, 100),
    emoji: String(item.emoji).trim().slice(0, 32)
  }));

  const now = new Date().toISOString();

  db.prepare(`
    INSERT INTO ticket_panels (guild_id, guild_name, config_json, updated_at)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(guild_id) DO UPDATE SET
      guild_name=excluded.guild_name,
      config_json=excluded.config_json,
      updated_at=excluded.updated_at
  `).run(guildId, guild.name, JSON.stringify({ command: "panel-ticket", options: clean }), now);

  res.json({ ok: true, message: "Configuración guardada correctamente." });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/index.html"));
});

app.listen(PORT, () => {
  console.log(`Security Bot Dashboard funcionando en http://localhost:${PORT}`);
});
